# NILEARN (Android) — by ahlaam

تطبيق تعليمي Offline-First بثيم **أسود وذهبي**. هذا مشروع أندرويد كامل جاهز للبناء إلى ملف APK.

## الطريقة 1 — بناء APK تلقائيًا ورابط تنزيل مباشر (الأسهل، بدون تثبيت أي شيء)

1. أنشئي حسابًا مجانيًا على https://github.com ثم مستودعًا جديدًا اسمه `nilearn` (عام Public).
2. ارفعي كل محتويات هذا المجلد إلى المستودع (زر **Add file → Upload files**، ومجلد `.github` يجب أن يُرفع أيضًا).
3. من تبويب **Actions** شغّلي **Build APK** (Run workflow)، أو أنشئي إصدارًا بوسم `v1.0.0`:
   `git tag v1.0.0 && git push origin v1.0.0`
4. بعد دقائق يظهر الملف في **Releases**، ورابطه المباشر يكون بالشكل:
   `https://github.com/<اسم-المستخدم>/nilearn/releases/latest/download/NILEARN.apk`
   هذا هو الرابط الذي تشاركينه مع الناس لتنزيل التطبيق.

## الطريقة 2 — البناء على جهازك

افتحي المجلد في **Android Studio** ثم **Build → Build APK(s)**، أو من الطرفية:

```
gradle assembleRelease
```

الملف الناتج: `app/build/outputs/apk/release/app-release.apk`

## سياسة الخصوصية (رابط عام مطلوب)

الملف `docs/privacy-policy.html` جاهز. لنشره كرابط:
في المستودع: **Settings → Pages → Branch: main / folder: /docs**، فيصبح الرابط:
`https://<اسم-المستخدم>.github.io/nilearn/privacy-policy.html`

## ملاحظات

- الـ APK موقّع بمفتاح debug ليُثبَّت مباشرة من الرابط. للنشر على Google Play أنشئي keystore خاصًا بك.
- المحتوى الحالي (مقرران تجريبيان) مثال؛ عدّلي `app/src/main/assets/index.html` (ثابت `COURSES`).
- المزامنة والتصحيح على الخادم والمعلّم الذكي تحتاج خادمًا (Backend) غير مضمَّن هنا؛ ضعي رابطه في `SYNC_URL`.
- اللوقو: `brand/logo.svg` (ومنه أيقونات التطبيق).
- حقوق النشر: `COPYRIGHT.md` — © ahlaam.
